import random


class JustePrix:
    def __init__(
        self, a=1, b=1000, strategie={"nombre_essais": 7, "multiplicateur de mise": 5}
    ):
        self.a = a
        self.b = b
        self.strategie = strategie

    def bot(self):
        n = random.randint(self.a, self.b)
        essai = 0
        trouve = False
        a, b = self.a, self.b
        while not trouve:
            essai += 1
            guess = (a + b) // 2
            if guess > n:
                b = guess - 1
            elif guess < n:
                a = guess + 1
            else:
                trouve = True
        return essai

    def esperance(self, n: int = 10_000_000):
        benef = 0
        mise = 1
        for i in range(n):
            if i % 1_000_000 == 0:
                print(i)
            if self.bot() <= self.strategie["nombre_essais"]:
                benef -= (mise * self.strategie["multiplicateur de mise"]) - mise
            else:
                benef += mise
        return benef / n


juste_prix = JustePrix()
print(juste_prix.esperance_roulette())
