import random


class Craps:
    def __init__(
        self,
        gain=(7, 11),
        perte=(2, 3, 12),
        point=(4, 5, 6, 8, 9, 10),
        strategie=None
    ):
        self.gain = gain
        self.perte = perte
        self.point = point

        if strategie is None:
            strategie = {
                "mise": 10,
                "nombre_essais": 1,
                "multiplicateur de mise": 2
            }

        self.strategie = strategie

    def lancer_des(self, manuel=True):
        if manuel:
            input("\nLancer les dés...")

        de1 = random.randint(1, 6)
        de2 = random.randint(1, 6)

        total = de1 + de2

        print("Dé 1 :", de1)
        print("Dé 2 :", de2)
        print("Total :", total)

        return total

    def joueur(self):
        total = self.lancer_des(True)

        if total in self.gain:
            print("gain")
            return "gain"

        elif total in self.perte:
            print("perte")
            return "perte"

        elif total in self.point:
            point = total
            print("point")

            while True:
                total = self.lancer_des(True)

                if total == point:
                    print("gain")
                    return "gain"

                elif total == 7:
                    print("perte")
                    return "perte"

    def mise(self):
        return self.strategie["mise"]

    def bot(self):
        mise = self.strategie["mise"]
        multiplicateur = self.strategie["multiplicateur de mise"]
        nombre_essais = self.strategie["nombre_essais"]

        benefice = 0

        for k in range(nombre_essais):
            total = self.lancer_des(True)

            if total in self.gain:
                print("gain")
                resultat = "gain"

            elif total in self.perte:
                print("perte")
                resultat = "perte"

            elif total in self.point:
                point = total
                print("point")

                while True:
                    total = self.lancer_des(True)

                    if total == point:
                        print("gain")
                        resultat = "gain"
                        break

                    elif total == 7:
                        print("perte")
                        resultat = "perte"
                        break

            if resultat == "gain":
                benefice += mise
                mise = self.strategie["mise"]

            elif resultat == "perte":
                benefice -= mise
                mise *= multiplicateur

        return benefice

    def esperance(self, n=100_000):
        benef = 0

        for i in range(n):
            benef += self.bot()

        return benef / n


craps = Craps()
print("Stratégie :", craps.strategie)
print("Mise :", craps.mise())
joueur = craps.joueur()
print("Joueur :", joueur)
print("Espérance :", craps.esperance())
bot = craps.bot()
print("Bot :", bot)
print("Espérance :", craps.esperance())