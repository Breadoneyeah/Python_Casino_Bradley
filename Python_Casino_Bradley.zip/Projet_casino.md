### Explication du projet

Un directeur de casino souhaite apporté de la nouveauté à son offre et fait appel à vous pour créer un jeu.
A l'instar des jeux de fêtes forraine, il souhaite que son nouveau jeu attire beaucoup d'utilisateurs. Pour cela, vous allez devoir créer un jeu pour lequel il semble facile de gagner.

### Consignes techniques et livrables

Vous devrez créer une classe qui correspond à votre jeu de casino. Cette classe devra contenir une méthode permettant de jouer à votre jeu en tant qu'utilisateur et une méthode dans laquelle le jeu est automatisé.
La méthode automatisée vous permettra de calculer une espérance de gain obtenue par la loi des grands nombres.
L'un des jeux icôniques des casino est la roulette. Comparez l'espérance de votre jeu avec celle de la roulette pour avoir une référence.

### Fin et rendu

Demain entre 15h30 et 17h, chaque étudiant sera à la fois joueur et "casino". Vous jouerez au jeu de chacun de vos camarades et chacun de vos camarades jouera au votre. Vous choisirez pour chaque jeu votre mise en fonction de votre espérance de gain.

Le joueur qui termine le jeu avec le plus gros capital remporte le jeu.
